using Ostryzhnyi.QuickRollGame.Scripts.WindowsService.ResultWindows.BaseClasses;

namespace Ostryzhnyi.QuickRollGame.Scripts.WindowsService.ResultWindows
{
    public class LoosePopup : ResultPopup
    {
    }
}