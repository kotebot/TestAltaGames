using UnityEngine;

namespace Ostryzhnyi.QuickRollGame.Scripts.Player.Impl.Finish
{
    public class Finish : MonoBehaviour
    {
    }
}