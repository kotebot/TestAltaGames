namespace Ostryzhnyi.QuickRollGame.Scripts.Player.Api
{
    public interface IPlayerShooter
    {
        public void Spawn();
        public void Shoot();
    }
}