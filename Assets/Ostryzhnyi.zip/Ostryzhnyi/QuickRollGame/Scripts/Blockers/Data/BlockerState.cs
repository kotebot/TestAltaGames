namespace Ostryzhnyi.QuickRollGame.Scripts.Blockers.Data
{
    public enum BlockerState
    {
        Ready,
        Removing,
        Removed
    }
}