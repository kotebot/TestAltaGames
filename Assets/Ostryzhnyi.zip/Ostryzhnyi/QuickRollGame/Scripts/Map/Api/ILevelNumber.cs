﻿namespace Ostryzhnyi.QuickRollGame.Scripts.Map.Api
{
    public interface ILevelNumber
    {
        public int LevelNumber { get; set; }
    }
}